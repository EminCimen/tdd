java 21 ve junit ile çalışacak bir program yapacağız.
api şeklinde çalışacak ve post isteği ile ad ve yaş bilgileri alınacak.
18 yaşından küçük ise hata dönecek.
18 yaşından büyük ise selamlama mesajı dönecek.
amacımız iyi testler yazmak ve kodun iyi okunabilir olması. modüler bir yapı olması.
testler ve class isimleri ingilizce olacak.
testlerde mocking yapılacak.
