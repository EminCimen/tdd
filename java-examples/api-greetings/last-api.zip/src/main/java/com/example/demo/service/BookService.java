package com.example.demo.service;

import com.example.demo.model.Book;
import com.example.demo.repository.BookRepository;
import org.springframework.stereotype.Service;

@Service
public class BookService {

    //Basım yılı 2015'ten küçük olamaz
    //Kitap ismi en az 3 karakter olmalıdır
    //Kitap ve yazar ismi aynı olamaz
    //Kitap ismi tamamen büyük harflerden oluşamaz 
} 